const axios = require("axios")
const fs = require("fs")
const {
  proto,
  prepareWAMessageMedia,
  generateWAMessageFromContent
} = require("@whiskeysockets/baileys")

const { tiktokDl } = require("./tiktok.js")
const ImGQuoted = fs.readFileSync('./Gambar/Quoted.jpg');

const OrderQt = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2029",
      thumbnail: ImGQuoted,
      itemCount: 9999999,
      status: "INQUIRY",
      surface: "CATALOG",
      message: "- Xena V5",
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    },
    contextInfo: {
      forwardingScore: 999,
      isForwarded: true
    }
  }
};

async function fetchJson(url, options = {}) {
  const res = await axios({
    url,
    method: "GET",
    ...options
  })
  return res.data
}

module.exports.tiktok = async (sock, m, text, ReplyGwe) => {
  try {
    if (!text) return ReplyGwe("❌ Masukkan link TikTok!")
    if (!/^https?:\/\//.test(text)) return ReplyGwe("❌ Link tidak valid!")

    ReplyGwe("⏳ Mengambil data TikTok...")

    const res = await tiktokDl(text)
    if (!res.status) return ReplyGwe("❌ Gagal mengambil data!")

    const info =
`*🎵 TikTok Downloader*
📌 *Judul:* ${res.title}
👤 *Author:* ${res.author.nickname} (@${res.author.username})
👀 *Views:* ${res.stats.views}
❤️ *Likes:* ${res.stats.likes}
💬 *Comment:* ${res.stats.comment}
🔁 *Share:* ${res.stats.share}
📅 *Upload:* ${res.taken_at}`

    if (res.duration == 0) {
      let cards = []
      let no = 1

      for (let img of res.data) {
        let media = await prepareWAMessageMedia(
          { image: { url: img.url } },
          { upload: sock.waUploadToServer }
        )

        cards.push({
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: `📸 Slide ${no++}`,
            hasMediaAttachment: true,
            ...media
          }),
          nativeFlowMessage:
            proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
              buttons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "🔗 Buka Foto",
                    url: img.url
                  })
                }
              ]
            })
        })
      }

      const msg = await generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessageV2Extension: {
            message: {
              interactiveMessage:
                proto.Message.InteractiveMessage.fromObject({
                  body: { text: info },
                  carouselMessage: { cards }
                })
            }
          }
        },
        { quoted: m, userJid: m.sender }
      )

      return sock.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
      })
    }

    const video =
      res.data.find(v => v.type === "nowatermark_hd") ||
      res.data.find(v => v.type === "nowatermark")

    await sock.sendMessage(
      m.chat,
      {
        video: { url: video.url },
        mimetype: "video/mp4",
        caption: info
      },
      { quoted: OrderQt }
    )

  } catch (e) {
    console.error(e)
    ReplyGwe("❌ Terjadi kesalahan sistem!")
  }
}

module.exports.instagram = async (sock, m, text, ReplyGwe) => {
  try {
    if (!text) return ReplyGwe("❌ Masukkan link Instagram!")
    if (!/^https?:\/\//.test(text)) return ReplyGwe("❌ Link tidak valid!")

    await sock.sendMessage(m.chat, {
      react: { text: "🕖", key: m.key }
    })

    const res = await fetchJson(
      `https://api.siputzx.my.id/download/igdl?url=${encodeURIComponent(text)}`
    )

    if (!res.status) return ReplyGwe("❌ Media tidak ditemukan!")

    await sock.sendMessage(
      m.chat,
      {
        video: { url: res.result.url },
        mimetype: "video/mp4",
        caption: "*✅ Instagram Downloader*"
      },
      { quoted: m }
    )

    await sock.sendMessage(m.chat, {
      react: { text: "", key: m.key }
    })

  } catch (e) {
    console.error(e)
    ReplyGwe("❌ Terjadi kesalahan!")
  }
}