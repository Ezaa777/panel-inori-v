const fs = require('fs')
const premGroupPath = './Acces/Group.json'

async function loadPremGroup () {
  if (!fs.existsSync(premGroupPath)) {
    fs.writeFileSync(premGroupPath, '[]')
  }
  return JSON.parse(fs.readFileSync(premGroupPath))
}

async function savePremGroup (data) {
  fs.writeFileSync(premGroupPath, JSON.stringify(data, null, 2))
}

async function isPremGroup (jid) {
  const data = await loadPremGroup()
  return data.includes(jid)
}

async function addPremGroup (jid) {
  const data = await loadPremGroup()
  if (data.includes(jid)) return false
  data.push(jid)
  await savePremGroup(data)
  return true
}

async function delPremGroup (jid) {
  const data = await loadPremGroup()
  const filtered = data.filter(v => v !== jid)
  await savePremGroup(filtered)
}

module.exports = {
  loadPremGroup,
  savePremGroup,
  isPremGroup,
  addPremGroup,
  delPremGroup
}