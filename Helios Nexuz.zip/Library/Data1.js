// file uploadCatbox.js
const fetch = require('node-fetch')
const FormData = require('form-data')
const { fromBuffer } = require('file-type')

/**
 * Upload image ke catbox.moe
 * @param {Buffer} buffer Image Buffer
 * @returns {Promise<string>} URL hasil upload
 */
async function uploadCatbox(buffer) {
  let fileType = await fromBuffer(buffer)
  let ext = fileType ? fileType.ext : "png"   // fallback ke png kalau undefined

  let bodyForm = new FormData()
  bodyForm.append("fileToUpload", buffer, "file." + ext)
  bodyForm.append("reqtype", "fileupload")

  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  })

  let data = await res.text()
  return data.trim()
}

module.exports = { uploadCatbox }