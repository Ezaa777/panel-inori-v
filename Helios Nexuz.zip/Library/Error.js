const axios = require("axios")

const TokenBot = "BOT_TOKEN"
const OwnerId = "OWNER_ID"

async function CekError(text) {
  try {
    await axios.post(
      `https://api.telegram.org/bot${TokenBot}/sendMessage`,
      {
        chat_id: OwnerId, // ← FIX DI SINI
        text,
        parse_mode: "HTML"
      }
    )
  } catch (err) {
    console.log("Gagal kirim ke Telegram:", err.response?.data || err.message)
  }
}

module.exports = { CekError }